<!-- starting footer -->
<footer class="container-fluid bg2">
  <div class="row">
    <div class="col-1 text-end mt-4">
      <div class="row"></div>
      <img src="./public/images/logo.png" width="65px">
    </div>

    <div class="col mt-4">
      <div>
      </div>
<h6>DEPARTMENT OF COMPUTER SCIENCE <br> & INFORMATION TECHNOLOGY <br>  STUDENTS ASSOCIATION
</h6>
    </div>

<div class="cols ">

  <p>

<h5 class="fw-bold heading3">USEFUL LINKS</h5><br>
UCC Website<br>
Student Portal<br>
Department Executive<br>
Register courses. <br>
  </p>
</div>

<div class="col">
  <div>
    <h5 class="fw-bold mt-3 heading3">
      CONTACT US<br>
    </h5>
    <p>
      Citsa@ucc.edu.gh <br>
      +233500515042
    </p>
    <h5 class="fw-bold mt-3 heading3">
      FOLLOW US<br>
        </h5>
        <div class="h3">
          <i class="bi bi-facebook"></i>
          <i class="bi bi-lindedln"></i>
          <i class="bi bi-twitter"></i>
          
        </div>
  </div>
</div>

</div>
<h6 class="text-center mt-3">@ CITSA UCC 2022</h6>
</div>
</footer>
<!-- ending footer -->
</body>
</html>