<!-- start navbar -->
<nav class="navbar navbar-expand-lg " id="nav" >
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="./public/images/logo.png" alt="" width="50" height="50">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- nav links -->
<div class="collapse navbar-collapse justify-content-end" id="navbarNav">
  <ul class="navbar-nav">
    <a class="nav-link active" aria-current="page" href="#">Home</a>
<hr style="margin-top: -7px;height: 5px; width: 40%;margin-left: 8px;background-color: blue;">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Gallery</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Clubs</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">About us</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Contact us</a>
    </li>
    <li class="nav-link">
      <a class="btn btn-primary">member login</a>
    </li>
  </ul>
</div>
      <!-- end nav link -->
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
          <a class="nav-link" href="#">GALLERY</a>
          <a class="nav-link" href="#">ABOUT US</a>
          <a class="nav-link" href="#">CLUBS</a>
          <a class="nav-link" href="#">CONTACT US</a>


          <a class="nav-link" href="login.php" id="login-button">MEMBER LOGIN</a>

        </div>
      </div>
    </div>
  </nav>
 <!-- end navbar -->