<?php

class User{
    public function createUser(){
        echo 'user create class'
    }
}